# Mobile Mechanic Shop OS - GitHub Pages

Upload `index.html` and `delete-account.html` to the ROOT of your existing
GitHub Pages repository.

Your GitHub Pages URLs will look like:

Privacy policy:
https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/

Account deletion:
https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/delete-account.html

After uploading:
1. Commit the files to the branch used by GitHub Pages (normally `main`).
2. Wait for the GitHub Pages deployment to complete.
3. Open both URLs in an incognito/private browser window.
4. Put the root URL in Google Play's Privacy Policy field.
5. Put the `/delete-account.html` URL in Google Play's Delete account URL field.

IMPORTANT:
These pages describe the planned v3.8 feature set discussed for Mobile Mechanic
Shop OS. Before production, ensure the text and Google Play Data Safety form
match the ACTUAL SDKs and data flows in the AAB being submitted.
